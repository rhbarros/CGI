import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager

# ===== CONFIGURAÇÃO =====
download_dir = r"C:\Hunter Club\py - anatel mosaico Hunter Club\Downloads"
headless = False  # ➜ Altere para True se quiser rodar sem abrir o navegador

# ===== PREPARA O CHROME =====
options = Options()
prefs = {
    "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "directory_upgrade": True
}
options.add_experimental_option("prefs", prefs)
if headless:
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")

# ===== LIMPA ARQUIVOS ANTIGOS =====
print("🧹 Limpando arquivos .zip antigos...")
for f in os.listdir(download_dir):
    if f.endswith(".zip"):
        try:
            os.remove(os.path.join(download_dir, f))
            print(f"  ➜ Removido: {f}")
        except Exception as e:
            print(f"⚠️ Não foi possível remover {f}: {e}")

# ===== CAPTURA UF =====
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
driver.get("https://sistemas.anatel.gov.br/se/public/view/b/licenciamento.php")
time.sleep(5)

filtrar_btn_xpath = "//span[contains(@onclick, 'toggleFilter')]"
WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.XPATH, filtrar_btn_xpath))).click()

WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.ID, "fc_8")))
uf_select_element = Select(driver.find_element(By.ID, "fc_8"))
ufs = [option.get_attribute("value") for option in uf_select_element.options if option.get_attribute("value")]

driver.quit()

# ===== FUNÇÃO: verifica se o download terminou =====
def is_download_complete(directory):
    return not any(f.endswith(".crdownload") or f.endswith(".tmp") for f in os.listdir(directory))

# ===== LOOP PRINCIPAL =====
downloaded_files = []

for uf in ufs:
    print(f"\n➡ Processando UF: {uf}")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver.get("https://sistemas.anatel.gov.br/se/public/view/b/licenciamento.php")
    time.sleep(5)

    print("➡ Esperando botão 'Filtrar'...")    
    try:
        WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.XPATH, filtrar_btn_xpath))).click()
    except TimeoutException:
        print("❌ Botão 'Filtrar' não encontrado.")
        driver.quit()
        continue

    print("➡ Selecionando UF...")
    try:
        WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "fc_8")))
        Select(driver.find_element(By.ID, "fc_8")).select_by_value(uf)
    except Exception as e:
        print(f"❌ Erro ao selecionar UF '{uf}': {e}")
        driver.quit()
        continue

    time.sleep(2)

    # Fecha modal se aparecer
    try:
        modal = WebDriverWait(driver, 5).until(EC.visibility_of_element_located((By.CLASS_NAME, "modalBackground")))
        close_button = modal.find_element(By.XPATH, ".//button[contains(@class, 'close')]")
        close_button.click()
        print("ℹ️ Modal fechado.")
    except:
        pass

    # Clica no botão de download
    try:
        download_button = driver.find_element(By.XPATH, "//button[@id='download_csv']")
        driver.execute_script("arguments[0].click();", download_button)
    except Exception as e:
        print(f"❌ Erro no download: {e}")
        driver.quit()
        continue

    # Aguarda o novo arquivo aparecer
    files_before = set(os.listdir(download_dir))
    timeout = 240
    elapsed = 0
    new_file = None

    print("⏳ Aguardando download...")
    while elapsed < timeout:
        time.sleep(1)
        if is_download_complete(download_dir):
            files_after = set(os.listdir(download_dir))
            new_files = files_after - files_before
            for f in new_files:
                if f.endswith(".zip"):
                    new_file = f
                    downloaded_files.append((uf, f))
                    print(f"✅ Download concluído: {f}")
                    break
        if new_file:
            break
        elapsed += 1
    else:
        print("❌ Tempo limite atingido para download.")

    driver.quit()

# ===== RENOMEIA ARQUIVOS =====
print("\n🔄 Renomeando arquivos baixados...")
for uf, original_file in downloaded_files:
    old_path = os.path.join(download_dir, original_file)
    new_path = os.path.join(download_dir, f"{uf}.zip")
    try:
        os.rename(old_path, new_path)
        print(f"✔ {original_file} ➜ {uf}.zip")
    except Exception as e:
        print(f"❌ Erro ao renomear {original_file}: {e}")

# ===== SALVA RELATÓRIO =====
relatorio_path = os.path.join(download_dir, "relatorio_downloads.csv")
with open(relatorio_path, "w", encoding="utf-8") as f:
    f.write("UF,Arquivo\n")
    for uf, file in downloaded_files:
        f.write(f"{uf},{file}\n")
print(f"\n📄 Relatório salvo em: {relatorio_path}")

# ===== VALIDAÇÃO FINAL =====
print("\n📁 Arquivos finais no diretório:")
zip_files = [f for f in os.listdir(download_dir) if f.endswith(".zip")]
for f in sorted(zip_files):
    print(f"  • {f}")

print(f"\n✅ Total de arquivos .zip encontrados: {len(zip_files)}")
if len(zip_files) == 27:
    print("🎉 Tudo certo! 27 arquivos baixados e renomeados com sucesso.")
else:
    print("⚠️ Atenção: quantidade diferente de 27. Verifique manualmente.")
