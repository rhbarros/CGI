import os
import zipfile

# ===== CONFIGURAÇÃO =====
download_dir = r"C:\Hunter Club\py - anatel mosaico Hunter Club\Downloads"  # ➜ Altere se necessário

print("📦 Iniciando extração dos arquivos .zip...")

zip_files = [f for f in os.listdir(download_dir) if f.endswith(".zip")]

for zip_name in zip_files:
    zip_path = os.path.join(download_dir, zip_name)
    uf_name = os.path.splitext(zip_name)[0]
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Assume que só tem 1 arquivo CSV dentro
            csv_name_inside_zip = [f for f in zip_ref.namelist() if f.endswith('.csv')][0]
            with zip_ref.open(csv_name_inside_zip) as source_file:
                output_csv_path = os.path.join(download_dir, f"{uf_name}.csv")
                with open(output_csv_path, "wb") as out_file:
                    out_file.write(source_file.read())
        print(f"✔ Extraído: {uf_name}.csv")
    except Exception as e:
        print(f"❌ Erro ao extrair {zip_name}: {e}")

print("\n✅ Extração finalizada.")
